# Constellation Creator - Static Website

This is a standalone version of Constellation Creator that works as a static website without requiring a server.

## Hosting Options

### 1. GitHub Pages (Free)
1. Create a GitHub repository
2. Upload the `index.html` file
3. Enable GitHub Pages in repository settings
4. Access at: `https://yourusername.github.io/repository-name`

### 2. Netlify (Free)
1. Go to netlify.com
2. Drag and drop the `standalone` folder
3. Get instant URL

### 3. Vercel (Free)
1. Go to vercel.com
2. Import from GitHub or upload folder
3. Deploy instantly

### 4. Surge.sh (Free)
```bash
npm install -g surge
cd standalone
surge
```

### 5. Firebase Hosting (Free)
```bash
npm install -g firebase-tools
firebase login
firebase init hosting
firebase deploy
```

## Local Testing
Simply open `index.html` in any web browser.